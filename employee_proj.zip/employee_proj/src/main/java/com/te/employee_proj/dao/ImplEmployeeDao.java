package com.te.employee_proj.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.transaction.Transaction;

import org.springframework.stereotype.Repository;

import com.te.employee_proj.beans.EmployeeInfo;
@Repository
public class ImplEmployeeDao implements IEmployeeDao{

	@Override
	public EmployeeInfo authenticate(int id,String password) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("Employee_Info");
		EntityManager manager=factory.createEntityManager();
		
		EmployeeInfo  bean = manager.find(EmployeeInfo.class, id);
		if(bean!=null) {
			if(bean.getPassword().equals(password)) {
				System.out.println("Login Successfully");
				return bean;
			}
			else {
				System.out.println("Invalid Credential");
				return null;
			}
		}
		else {
			System.out.println("Invalid Credential");
			return null;
		}
	}

	@Override
	public EmployeeInfo getEmployee(int id) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("Employee_Info");
		EntityManager manager=factory.createEntityManager();
		EmployeeInfo employeeInfo=manager.find(EmployeeInfo.class,id);
		return employeeInfo;
	}

	@Override
	public boolean deleteEmp(int id) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("Employee_Info");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		
		EmployeeInfo bean = manager.find(EmployeeInfo.class ,id);
		manager.remove(bean);
		transaction.commit();
		if(bean!=null) {
			System.out.println("Deleted Successfully");
			return true;
		}
		else {
			System.out.println("Not able to delete");
			return false;
		}
	}
}
