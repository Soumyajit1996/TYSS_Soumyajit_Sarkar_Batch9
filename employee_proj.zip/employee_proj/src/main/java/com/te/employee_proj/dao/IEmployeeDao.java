package com.te.employee_proj.dao;

import com.te.employee_proj.beans.EmployeeInfo;

public interface IEmployeeDao {
	public EmployeeInfo authenticate(int id,String password);
	 public EmployeeInfo getEmployee(int id);
	 public boolean deleteEmp(int id);
}
