package com.te.employee_proj.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.te.employee_proj.beans.EmployeeInfo;
import com.te.employee_proj.dao.IEmployeeDao;


	

@Controller
public class EmpMVCController {
	
	@Autowired
	IEmployeeDao empdao;
	
	@GetMapping("/login")
	public String getLoginPage() {
		return"/WEB-INF/views/loginForm.jsp";
	}
	
	@PostMapping("/login")
	public String getLoginFormData(int id,String password,HttpServletRequest req,ModelMap map) {
		EmployeeInfo employeeInfo=empdao.authenticate(id,password);
		
		if(employeeInfo!=null) {
			HttpSession session=req.getSession(true);
			session.setAttribute("emp", employeeInfo);
			return "/WEB-INF/views/homePage.jsp";
		}
		else {
			map.addAttribute("errMsg" ,"Invalid Credential");
			return "/WEB-INF/views/loginForm.jsp";
		}
	}

	@GetMapping("/searchForm")
	public String getSearchForm(ModelMap map,HttpSession session) {
		
		if(session.getAttribute("emp")!=null) {
			return "/WEB-INF/views/searchForm.jsp";
		}
		else {
			map.addAttribute("errMsg","please login first");
			return "/WEB-INF/views/loginForm.jsp";
		}
	}
	
	@GetMapping("/search")
	public String searchEmp(int id,ModelMap map,
			@SessionAttribute(name="emp",required = false)EmployeeInfo employeeInfo ) {
		if(employeeInfo!=null) {
			EmployeeInfo employeeInfo2=empdao.getEmployee(id);
			if(employeeInfo2!=null) {
				map.addAttribute("data", employeeInfo2);
			}
			else {
				map.addAttribute("msg", "data not found for id "+id);
			}
			return "/WEB-INF/views/searchForm.jsp";
		}
		else {
			map.addAttribute("errMsg", "please login first");
			return "/WEB-INF/views/loginForm.jsp";
		}
	}
	
	@GetMapping("/logout")
	public String logOut(ModelMap map,HttpSession session) {
		session.invalidate();
		map.addAttribute("errMsg","Logout Successfully");
		
		return "/WEB-INF/views/loginForm.jsp";
	}
	
	@GetMapping("/deleteForm")
	public String deleteForm(ModelMap map,HttpSession session){
		if(session.getAttribute("emp")!=null) {
			return "/WEB-INF/views/deleteForm.jsp";
		}
		else {
			map.addAttribute("errMsg", "Please Login first");
			return "/WEB-INF/views/deleteForm.jsp";
		}
	}
	
	@GetMapping("/delete")
	public String deleteEmp(int id,@SessionAttribute(name="emp",required = false)EmployeeInfo employeeInfo,ModelMap map) {
		if(employeeInfo!=null) {
			boolean result=empdao.deleteEmp(id);
			if(result) {
				map.addAttribute("msg","Deleted Successfully");
			}
			else {
				map.addAttribute("errMsg", "Not Deleted Successfully");
			}
			return "/WEB-INF/views/deleteForm.jsp";
		}
		return "/WEB-INF/views/loginForm.jsp";
	}
}
